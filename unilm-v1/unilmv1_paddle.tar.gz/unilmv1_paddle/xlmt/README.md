
# XLM-T
**Multilingual NMT w/ pre-trained cross-lingual ecnoders**



**XLM-T** ```New``` (December, 2020): "[XLM-T: Scaling up Multilingual Machine Translation with Pretrained Cross-lingual Transformer Encoders](https://arxiv.org/abs/2012.15547)".

## License
This project is licensed under the license found in the LICENSE file in the root directory of this source tree.

[Microsoft Open Source Code of Conduct](https://opensource.microsoft.com/codeofconduct)

### Contact Information

For help or issues using InfoXLM, please submit a GitHub issue.

For other communications related to InfoXLM, please contact Li Dong (`lidong1@microsoft.com`), Furu Wei (`fuwei@microsoft.com`).

