import infoxlm

from fairseq_cli.train import cli_main


if __name__ == "__main__":
  cli_main()