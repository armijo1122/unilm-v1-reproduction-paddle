import setuptools

setuptools.setup(
  name="infoxlm",
  version="0.0.1",
  author="Zewen",
  author_email="chizewen@outlook.com",
  description="infoxlm",
  url="https://github.com/CZWin32768/XLM-Align",
  packages=setuptools.find_packages(),
  install_requires=[],
  classifiers=(
    "Programming Language :: Python :: 3",
    "License :: OSI Approved :: MIT License",
    "Operating System :: OS Independent",
  )
)