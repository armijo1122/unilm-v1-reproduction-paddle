# flake8: noqa
from .funsd import FunsdDataset
